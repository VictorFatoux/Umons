Fran�ais
********
Le fond UMONS pour slides �dit�s avec LaTeX a �t� d�velopp� par Christophe TROESTLER.
Vous trouverez ici la version 0.2.

Les fichiers sont mis � jour via la forge UMONS, dont voici le lien:
https://forge.umons.ac.be/redmine/projects/beamer-umons/files

English
*******
The UMONS template to create slides thanks to LaTeX has been developed by Christophe TROESTLER.
You find here the version 0.2.

The files are updated on the "forge UMONS" website, whose the link is the following:
https://forge.umons.ac.be/redmine/projects/beamer-umons/files